$(document).ready(function(){
  $('#start_button').click(function(){
    window.location.href = "./Quiz/quiz.html";
  })
})